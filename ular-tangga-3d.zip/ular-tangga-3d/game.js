/*!
 * Ular Tangga 3D - mesin permainan (HTML5 + CSS3 + JavaScript murni + three.js)
 * ---------------------------------------------------------------------------
 * Skrip klasik (bukan ES module) supaya file bisa dibuka langsung dari disk
 * (file://) maupun dari server web. three.js dimuat lebih dulu lewat
 * <script src="lib/three.js"> dan tersedia sebagai window.THREE.
 *
 * Pemakaian:
 *   UlarTanggaEngine.createGame(document.getElementById('ut-root'), { apiBase: '/api' })
 *   -> mengembalikan { destroy() }
 *
 * Bank soal: dicoba dari GET {apiBase}/questions, kalau gagal (offline) otomatis
 * memakai DEFAULT_QUESTIONS di bawah ini. Edit daftar itu untuk menambah soal.
 */
(function (global) {
  "use strict";

  var THREE = global.THREE;
  if (!THREE) {
    console.error("[ular-tangga] three.js belum dimuat. Sisipkan <script src=\"lib/three.js\"> sebelum game.js.");
    return;
  }

  /* ------------------------------- data ---------------------------------- */

  var WIN_TILE = 100;
  var ATTACK_COST = 20;
  var ATTACK_BACK = 3;
  var STEP_MS = 330;
  var TILE = 2.2;
  var BOARD_W = 22;
  var BOARD_TOP = 0.601;
  var PAWN_BASE_Y = BOARD_TOP;
  var DICE_Y = 0.9;
  var QUADRANTS = [
    [-0.44, -0.44],
    [0.44, -0.44],
    [-0.44, 0.44],
    [0.44, 0.44]
  ];

  var LADDERS = { 4: 14, 9: 31, 20: 38, 28: 84, 40: 59, 51: 67, 63: 81, 71: 91 };
  var SNAKES = { 17: 7, 54: 34, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 99: 78 };
  var SNAKE_COLORS = [0x15803D, 0x16A34A, 0x4ADE80, 0xDC2626];

  var PLAYER_PRESETS = [
    { name: "Pemain 1", label: "Merah", color: "#EF4444", hex: 0xef4444, soft: "#FEE2E2" },
    { name: "Pemain 2", label: "Biru", color: "#0EA5E9", hex: 0x0ea5e9, soft: "#E0F2FE" },
    { name: "Pemain 3", label: "Kuning", color: "#F59E0B", hex: 0xf59e0b, soft: "#FEF3C7" },
    { name: "Pemain 4", label: "Hijau", color: "#10B981", hex: 0x10b981, soft: "#D1FAE5" }
  ];

  var CATEGORY_LABELS = {
    matematika: "Matematika",
    ipa: "IPA & Alam",
    ips: "IPS & Budaya",
    bahasa: "Bahasa & Logika",
    teknologi: "Teknologi",
    umum: "Pengetahuan Umum"
  };

  /* Bank soal bawaan (tingkat SD) - dipakai kalau API tidak tersedia. */
  var DEFAULT_QUESTIONS = [
    { text: "Hasil dari 7 x 8 adalah ...", options: ["48", "54", "56", "64"], answer_index: 2, explanation: "7 x 8 = 56, sama artinya dengan 7 dijumlahkan sebanyak 8 kali.", category: "matematika" },
    { text: "Hasil dari 144 : 12 adalah ...", options: ["10", "12", "13", "14"], answer_index: 1, explanation: "144 dibagi 12 sama dengan 12, karena 12 x 12 = 144.", category: "matematika" },
    { text: "Keliling persegi dengan panjang sisi 9 cm adalah ...", options: ["18 cm", "27 cm", "36 cm", "81 cm"], answer_index: 2, explanation: "Keliling persegi = 4 x sisi = 4 x 9 cm = 36 cm.", category: "matematika" },
    { text: "KPK (Kelipatan Persekutuan Terkecil) dari 4 dan 6 adalah ...", options: ["8", "10", "12", "24"], answer_index: 2, explanation: "Kelipatan 4: 4, 8, 12, ... Kelipatan 6: 6, 12, ... Yang sama dan terkecil adalah 12.", category: "matematika" },
    { text: "Ibu membeli 3 kg apel dengan harga Rp15.000 per kg. Uang yang harus dibayar adalah ...", options: ["Rp30.000", "Rp45.000", "Rp50.000", "Rp18.000"], answer_index: 1, explanation: "3 kg x Rp15.000 = Rp45.000.", category: "matematika" },
    { text: "Bagian tumbuhan yang menyerap air dan zat hara dari dalam tanah adalah ...", options: ["daun", "akar", "batang", "bunga"], answer_index: 1, explanation: "Akar menyerap air dan zat hara dari dalam tanah untuk tumbuhan.", category: "ipa" },
    { text: "Perubahan wujud benda dari cair menjadi gas disebut ...", options: ["membeku", "menguap", "mencair", "mengembun"], answer_index: 1, explanation: "Menguap adalah perubahan wujud dari cair menjadi gas, contohnya air yang mendidih.", category: "ipa" },
    { text: "Hewan berikut yang mengalami metamorfosis sempurna adalah ...", options: ["kupu-kupu", "ayam", "kucing", "ikan"], answer_index: 0, explanation: "Kupu-kupu melewati tahap telur, ulat, kepompong, lalu kupu-kupu dewasa.", category: "ipa" },
    { text: "Organ tubuh manusia yang bertugas memompa darah ke seluruh tubuh adalah ...", options: ["paru-paru", "jantung", "lambung", "ginjal"], answer_index: 1, explanation: "Jantung memompa darah agar beredar ke seluruh tubuh.", category: "ipa" },
    { text: "Gaya yang menyebabkan benda jatuh ke bawah adalah gaya ...", options: ["magnet", "gesek", "gravitasi", "pegas"], answer_index: 2, explanation: "Gaya gravitasi bumi menarik benda ke bawah.", category: "ipa" },
    { text: "Ibu kota Provinsi Jawa Barat adalah ...", options: ["Semarang", "Bandung", "Surabaya", "Serang"], answer_index: 1, explanation: "Bandung adalah ibu kota Provinsi Jawa Barat.", category: "ips" },
    { text: "Candi Borobudur terletak di Provinsi ...", options: ["Jawa Timur", "Jawa Tengah", "Jawa Barat", "Bali"], answer_index: 1, explanation: "Candi Borobudur berada di Magelang, Jawa Tengah.", category: "ips" },
    { text: "Alat musik angklung berasal dari daerah ...", options: ["Jawa Barat", "Sumatra Utara", "Bali", "Papua"], answer_index: 0, explanation: "Angklung berasal dari Jawa Barat dan terbuat dari bambu.", category: "ips" },
    { text: "Rumah adat Tongkonan berasal dari Provinsi ...", options: ["Sulawesi Selatan", "Kalimantan Timur", "Nusa Tenggara Barat", "Maluku"], answer_index: 0, explanation: "Tongkonan adalah rumah adat suku Toraja di Sulawesi Selatan.", category: "ips" },
    { text: "Presiden pertama Republik Indonesia adalah ...", options: ["Mohammad Hatta", "Ir. Soekarno", "Soeharto", "B.J. Habibie"], answer_index: 1, explanation: "Ir. Soekarno memimpin Indonesia sebagai presiden pertama sejak 1945.", category: "ips" },
    { text: "Persamaan kata (sinonim) dari 'pandai' adalah ...", options: ["malas", "cerdas", "lambat", "ramah"], answer_index: 1, explanation: "Pandai bersinonim dengan cerdas atau pintar.", category: "bahasa" },
    { text: "Lawan kata (antonim) dari 'tinggi' adalah ...", options: ["besar", "rendah", "jauh", "panjang"], answer_index: 1, explanation: "Antonim dari tinggi adalah rendah.", category: "bahasa" },
    { text: "Kata 'sekolah' terdiri dari ... suku kata.", options: ["2 suku kata", "3 suku kata", "4 suku kata", "5 suku kata"], answer_index: 1, explanation: "Se-ko-lah, jadi ada 3 suku kata.", category: "bahasa" },
    { text: "Lanjutkan pola bilangan berikut: 2, 4, 6, 8, ...", options: ["9", "10", "11", "12"], answer_index: 1, explanation: "Bilangan bertambah 2 setiap langkah, jadi setelah 8 adalah 10.", category: "bahasa" },
    { text: "Semua kucing suka ikan. Si Belang adalah kucing. Maka Si Belang ...", options: ["tidak suka ikan", "suka ikan", "suka tulang", "bukan kucing"], answer_index: 1, explanation: "Karena semua kucing suka ikan dan Si Belang adalah kucing, maka Si Belang suka ikan.", category: "bahasa" },
    { text: "Alat untuk mengetik huruf pada komputer disebut ...", options: ["monitor", "keyboard", "printer", "speaker"], answer_index: 1, explanation: "Keyboard dipakai untuk mengetik huruf dan angka.", category: "teknologi" },
    { text: "Bagian komputer yang menampilkan gambar dan tulisan adalah ...", options: ["monitor", "mouse", "CPU", "flashdisk"], answer_index: 0, explanation: "Monitor menampilkan hasil kerja komputer berupa gambar dan tulisan.", category: "teknologi" },
    { text: "Alat penyimpan data kecil yang mudah dibawa ke mana-mana adalah ...", options: ["flashdisk", "printer", "proyektor", "kabel"], answer_index: 0, explanation: "Flashdisk menyimpan data dan mudah dibawa karena ukurannya kecil.", category: "teknologi" },
    { text: "Mesin ATM di bank digunakan untuk ...", options: ["mencetak buku", "mengambil dan menyetor uang", "menelepon", "menggambar"], answer_index: 1, explanation: "ATM memudahkan nasabah mengambil atau menyetor uang.", category: "teknologi" },
    { text: "Program di internet yang membantu kita mencari informasi disebut ...", options: ["mesin pencari", "pengolah angka", "pemutar musik", "pengedit foto"], answer_index: 0, explanation: "Mesin pencari, misalnya Google, membantu menemukan informasi di internet.", category: "teknologi" },
    { text: "Alat untuk mengukur suhu tubuh adalah ...", options: ["penggaris", "termometer", "timbangan", "jam"], answer_index: 1, explanation: "Termometer dipakai untuk mengukur suhu, termasuk suhu tubuh.", category: "umum" },
    { text: "Warna yang dihasilkan dari campuran warna kuning dan biru adalah ...", options: ["merah", "hijau", "ungu", "oranye"], answer_index: 1, explanation: "Kuning dicampur biru menghasilkan warna hijau.", category: "umum" },
    { text: "Planet yang menjadi tempat tinggal makhluk hidup adalah ...", options: ["Mars", "Bumi", "Venus", "Matahari"], answer_index: 1, explanation: "Bumi adalah planet tempat tinggal makhluk hidup. Matahari adalah bintang, bukan planet.", category: "umum" },
    { text: "Jumlah pemain inti satu tim sepak bola adalah ...", options: ["9 orang", "10 orang", "11 orang", "12 orang"], answer_index: 2, explanation: "Satu tim sepak bola terdiri dari 11 pemain inti.", category: "umum" },
    { text: "Kegiatan mengerjakan soal untuk mengukur pemahaman setelah belajar disebut ...", options: ["ulangan", "istirahat", "upacara", "piket"], answer_index: 0, explanation: "Ulangan atau ujian dipakai untuk mengukur pemahaman siswa.", category: "umum" }
  ];

  var PIPS = {
    1: [[1, 1]],
    2: [[0, 0], [2, 2]],
    3: [[0, 0], [1, 1], [2, 2]],
    4: [[0, 0], [2, 0], [0, 2], [2, 2]],
    5: [[0, 0], [2, 0], [1, 1], [0, 2], [2, 2]],
    6: [[0, 0], [2, 0], [0, 1], [2, 1], [0, 2], [2, 2]]
  };
  var DICE_FACE_VALUES = [1, 6, 2, 5, 3, 4]; // urutan material BoxGeometry: +x, -x, +y, -y, +z, -z

  /* ----------------------------- utilitas -------------------------------- */

  function gridOf(tile) {
    var row = Math.floor((tile - 1) / 10);
    var col = (tile - 1) % 10;
    if (row % 2 === 1) col = 9 - col;
    return { row: row, col: col };
  }

  function tileToWorld(tile) {
    var g = gridOf(tile);
    return { x: (g.col - 4.5) * TILE, z: (4.5 - g.row) * TILE };
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function lerp(a, b, t) {
    return a + (b - a) * t;
  }

  function easeOutCubic(t) {
    return 1 - Math.pow(1 - t, 3);
  }

  function easeInOutQuad(t) {
    return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value).replace(/[&<>"']/g, function (ch) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
    });
  }

  function sanitizeQuestions(list) {
    if (!Array.isArray(list)) return [];
    return list.filter(function (item) {
      return (
        item &&
        typeof item.text === "string" &&
        item.text.trim().length > 2 &&
        Array.isArray(item.options) &&
        item.options.length === 4 &&
        item.options.every(function (option) { return typeof option === "string" && option.trim(); }) &&
        typeof item.answer_index === "number" &&
        item.answer_index >= 0 &&
        item.answer_index <= 3
      );
    });
  }

  /* --------------------------- tampilan HUD ------------------------------ */

  function setupTemplate() {
    var rows = PLAYER_PRESETS.map(function (preset, index) {
      var n = index + 1;
      return (
        '<label class="ut-input-row" for="ut-name-' + n + '">' +
        '<span class="ut-dot" style="background:' + preset.color + '"></span>' +
        '<span class="ut-input-label">Pemain ' + n + ' &#183; ' + preset.label + "</span>" +
        '<input id="ut-name-' + n + '" class="ut-input" type="text" maxlength="14" value="' + preset.name +
        '" data-testid="player-name-input-' + n + '" autocomplete="off" />' +
        "</label>"
      );
    }).join("");

    return (
      '<div class="ut-screen" data-testid="setup-screen">' +
      '<div class="ut-setup">' +
      '<p class="ut-overline">Game keluarga &#183; 4 pemain</p>' +
      '<h1 class="ut-title">Ular Tangga 3D</h1>' +
      '<p class="ut-sub">Isi nama keempat pemain, lalu bermain bergantian di satu perangkat. Jawab soal dengan benar untuk mengumpulkan poin dan serang lawanmu!</p>' +
      '<div class="ut-inputs">' + rows + "</div>" +
      '<div class="ut-chips">' +
      '<span class="ut-chip">&#127922; Dadu 1&#8211;6</span>' +
      '<span class="ut-chip">&#10067; Soal benar +10 poin</span>' +
      '<span class="ut-chip">&#9876;&#65039; 20 poin untuk menyerang</span>' +
      '<span class="ut-chip">&#129692; 8 tangga &#183; &#128013; 8 ular</span>' +
      "</div>" +
      '<button class="ut-btn ut-btn-primary ut-btn-start" type="button" data-testid="start-game-button">Mulai Bermain</button>' +
      '<p class="ut-note" data-testid="question-source-note">Memuat bank soal ...</p>' +
      "</div></div>"
    );
  }

  function hudTemplate() {
    var cards = PLAYER_PRESETS.map(function (preset, index) {
      var n = index + 1;
      return (
        '<div class="ut-player-card" data-testid="player-card-' + n + '">' +
        '<span class="ut-dot" style="background:' + preset.color + '"></span>' +
        '<span class="ut-player-meta">' +
        '<strong class="ut-player-name" data-testid="player-name-' + n + '">' + preset.name + "</strong>" +
        '<span class="ut-player-pos" data-testid="player-position-' + n + '">Petak 1</span>' +
        "</span>" +
        '<span class="ut-player-score" data-testid="player-score-' + n + '">0</span>' +
        "</div>"
      );
    }).join("");

    return (
      '<div class="ut-hud" data-testid="game-hud">' +
      '<div class="ut-hud-top">' +
      '<div class="ut-turn" data-testid="turn-banner"><span class="ut-turn-dot"></span><span data-testid="turn-text">Giliran Pemain 1</span></div>' +
      '<div class="ut-players" data-testid="player-tray">' + cards + "</div>" +
      '<div class="ut-tools">' +
      '<button class="ut-icon-btn" type="button" data-testid="camera-toggle-button" title="Ubah sudut kamera">&#127909;</button>' +
      '<button class="ut-icon-btn" type="button" data-testid="sound-toggle-button" title="Suara">&#128266;</button>' +
      '<button class="ut-icon-btn" type="button" data-testid="help-button" title="Aturan permainan">?</button>' +
      "</div>" +
      "</div>" +
      '<div class="ut-hud-bottom">' +
      '<div class="ut-dice-box"><span class="ut-dice-caption">Dadu</span><strong class="ut-dice-value" data-testid="dice-value">&#8211;</strong></div>' +
      '<button class="ut-btn ut-btn-roll" type="button" data-testid="roll-dice-button">&#127922; Lempar Dadu</button>' +
      '<button class="ut-btn ut-btn-attack" type="button" data-testid="attack-button">&#9876;&#65039; Serang (20 poin)</button>' +
      "</div>" +
      "</div>" +
      '<div class="ut-toasts" data-testid="toast-area"></div>' +
      '<p class="ut-live" aria-live="polite" role="status"></p>'
    );
  }

  /* ----------------------------- permainan ------------------------------- */

  function createGame(root, options) {
    if (!root) throw new Error("createGame butuh elemen root");
    var settings = options || {};
    var apiBase = settings.apiBase || "/api";

    var state = {
      phase: "setup",
      current: 0,
      dice: 0,
      players: PLAYER_PRESETS.map(function (preset, index) {
        return { index: index, name: preset.name, color: preset.color, soft: preset.soft, pos: 1, score: 0 };
      }),
      slots: {},
      questions: DEFAULT_QUESTIONS.slice(),
      questionSource: "bawaan",
      recentQuestions: [],
      soundOn: true,
      cameraMode: "iso"
    };

    /* ---------- DOM ---------- */
    root.classList.add("ut-root");
    root.innerHTML = '<canvas class="ut-canvas" data-testid="board-canvas"></canvas>' + setupTemplate() + hudTemplate();

    var el = {
      canvas: root.querySelector(".ut-canvas"),
      setup: root.querySelector('[data-testid="setup-screen"]'),
      note: root.querySelector('[data-testid="question-source-note"]'),
      hud: root.querySelector('[data-testid="game-hud"]'),
      turnText: root.querySelector('[data-testid="turn-text"]'),
      turnDot: root.querySelector(".ut-turn-dot"),
      cards: [],
      names: [],
      positions: [],
      scores: [],
      diceValue: root.querySelector('[data-testid="dice-value"]'),
      rollBtn: root.querySelector('[data-testid="roll-dice-button"]'),
      attackBtn: root.querySelector('[data-testid="attack-button"]'),
      cameraBtn: root.querySelector('[data-testid="camera-toggle-button"]'),
      soundBtn: root.querySelector('[data-testid="sound-toggle-button"]'),
      helpBtn: root.querySelector('[data-testid="help-button"]'),
      toasts: root.querySelector('[data-testid="toast-area"]'),
      live: root.querySelector(".ut-live"),
      inputs: []
    };
    for (var i = 1; i <= 4; i += 1) {
      el.cards.push(root.querySelector('[data-testid="player-card-' + i + '"]'));
      el.names.push(root.querySelector('[data-testid="player-name-' + i + '"]'));
      el.positions.push(root.querySelector('[data-testid="player-position-' + i + '"]'));
      el.scores.push(root.querySelector('[data-testid="player-score-' + i + '"]'));
      el.inputs.push(root.querySelector('[data-testid="player-name-input-' + i + '"]'));
    }

    /* ---------- three.js ---------- */
    var renderer = new THREE.WebGLRenderer({ canvas: el.canvas, antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(global.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;

    var scene = new THREE.Scene();
    var camera = new THREE.PerspectiveCamera(45, 1, 0.1, 400);

    var cam = { theta: 0, phi: 0.86, radius: 38, targetTheta: 0, targetPhi: 0.86, targetRadius: 38, fit: 38 };

    scene.add(new THREE.HemisphereLight(0xe0f2fe, 0xfef3c7, 1.5));
    scene.add(new THREE.AmbientLight(0xffffff, 0.45));
    var sun = new THREE.DirectionalLight(0xfff7e2, 2.4);
    sun.position.set(15, 30, 20);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.near = 5;
    sun.shadow.camera.far = 90;
    sun.shadow.camera.left = -22;
    sun.shadow.camera.right = 22;
    sun.shadow.camera.top = 22;
    sun.shadow.camera.bottom = -22;
    sun.shadow.bias = -0.0009;
    scene.add(sun);

    // papan + bayangan + nampan dadu
    var boardTexture = new THREE.CanvasTexture(drawBoardCanvas());
    boardTexture.colorSpace = THREE.SRGBColorSpace;
    boardTexture.anisotropy = renderer.capabilities.getMaxAnisotropy();

    var baseMat = new THREE.MeshStandardMaterial({ color: 0x8a5a2b, roughness: 0.8, metalness: 0.06 });
    var base = new THREE.Mesh(new THREE.BoxGeometry(BOARD_W + 1.7, 1.2, BOARD_W + 1.7), baseMat);
    base.receiveShadow = true;
    base.castShadow = true;
    scene.add(base);

    var topMat = new THREE.MeshStandardMaterial({ map: boardTexture, roughness: 0.62, metalness: 0.03 });
    var top = new THREE.Mesh(new THREE.PlaneGeometry(BOARD_W, BOARD_W), topMat);
    top.rotation.x = -Math.PI / 2;
    top.position.y = BOARD_TOP;
    top.receiveShadow = true;
    scene.add(top);

    var trimMat = new THREE.MeshStandardMaterial({ color: 0xb4793c, roughness: 0.65, metalness: 0.08 });
    var trim = new THREE.Mesh(new THREE.BoxGeometry(BOARD_W + 1.9, 0.22, BOARD_W + 1.9), trimMat);
    trim.position.y = 0.6;
    trim.castShadow = true;
    scene.add(trim);

    var ground = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), new THREE.ShadowMaterial({ opacity: 0.2 }));
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.61;
    ground.receiveShadow = true;
    scene.add(ground);

    var trayMat = new THREE.MeshStandardMaterial({ color: 0x6b4423, roughness: 0.85, metalness: 0.04 });
    var tray = new THREE.Mesh(new THREE.BoxGeometry(9.5, 0.6, 4.8), trayMat);
    tray.position.set(0, -0.3, 13.6);
    tray.receiveShadow = true;
    tray.castShadow = true;
    scene.add(tray);

    // tangga
    var railMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.5, metalness: 0.05 });
    Object.keys(LADDERS).forEach(function (from) {
      var group = buildLadder(Number(from), LADDERS[from], railMat);
      scene.add(group);
    });

    // ular
    Object.keys(SNAKES).forEach(function (from, index) {
      var group = buildSnake(Number(from), SNAKES[from], SNAKE_COLORS[index % SNAKE_COLORS.length], index * 1.3);
      scene.add(group);
    });

    // bidak
    var pawnObjects = PLAYER_PRESETS.map(function (preset) {
      var pawn = buildPawn(preset.hex);
      pawn.group.visible = false;
      scene.add(pawn.group);
      return pawn;
    });

    // dadu
    var diceMaterials = DICE_FACE_VALUES.map(function (value) {
      var texture = new THREE.CanvasTexture(drawPipCanvas(value));
      texture.colorSpace = THREE.SRGBColorSpace;
      return new THREE.MeshPhysicalMaterial({ map: texture, roughness: 0.35, metalness: 0.02, clearcoat: 0.35 });
    });
    var dice = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1.8, 1.8), diceMaterials);
    dice.castShadow = true;
    dice.position.set(0, DICE_Y, 13.6);
    dice.quaternion.copy(quaternionForValue(6));
    scene.add(dice);

    /* ---------- animasi ---------- */
    var tweens = [];
    var effects = [];

    function tween(duration, onUpdate) {
      return new Promise(function (resolve) {
        tweens.push({ elapsed: 0, duration: duration / 1000, onUpdate: onUpdate, resolve: resolve });
      });
    }

    function wait(ms) {
      return tween(ms, function () {});
    }

    function updateTweens(dt) {
      for (var i = tweens.length - 1; i >= 0; i -= 1) {
        var item = tweens[i];
        item.elapsed += dt;
        var k = clamp(item.elapsed / item.duration, 0, 1);
        item.onUpdate(k);
        if (k >= 1) {
          tweens.splice(i, 1);
          item.resolve();
        }
      }
    }

    /* ---------- kamera & render ---------- */
    function fitCamera() {
      var width = root.clientWidth || 1;
      var height = root.clientHeight || 1;
      var aspect = width / height;
      camera.aspect = aspect;
      camera.fov = aspect < 0.78 ? 55 : 45;
      camera.updateProjectionMatrix();
      var tan = Math.tan((camera.fov * Math.PI) / 360);
      var need = 15.5 / Math.min(tan * aspect, tan);
      cam.fit = clamp(need * 1.02, 34, 100);
      cam.targetRadius = clamp(cam.targetRadius, cam.fit * 0.55, cam.fit * 1.5);
      renderer.setSize(width, height, false);
    }

    var lastTime = performance.now();
    var spin = 0;
    renderer.setAnimationLoop(function () {
      var now = performance.now();
      var dt = Math.min(0.05, (now - lastTime) / 1000);
      lastTime = now;
      updateTweens(dt);

      if (state.phase === "setup") {
        spin += dt * 0.12;
        cam.theta = spin;
      } else {
        cam.theta += (cam.targetTheta - cam.theta) * 0.11;
      }
      cam.phi += (cam.targetPhi - cam.phi) * 0.11;
      cam.radius = state.phase === "setup" ? cam.fit : cam.radius + (cam.targetRadius - cam.radius) * 0.11;
      var r = cam.radius;
      camera.position.set(
        r * Math.sin(cam.phi) * Math.sin(cam.theta),
        r * Math.cos(cam.phi),
        r * Math.sin(cam.phi) * Math.cos(cam.theta)
      );
      camera.lookAt(0, 0.4, 0);

      pawnObjects.forEach(function (pawn, index) {
        var active = index === state.current && state.phase !== "setup" && state.phase !== "over";
        pawn.marker.visible = active;
        if (active) {
          pawn.marker.material.opacity = 0.55 + Math.sin(now / 260) * 0.35;
          pawn.marker.scale.setScalar(1 + Math.sin(now / 300) * 0.06);
        }
      });

      updateEffects(dt);
      renderer.render(scene, camera);
    });

    function updateEffects(dt) {
      for (var i = effects.length - 1; i >= 0; i -= 1) {
        var effect = effects[i];
        effect.elapsed += dt;
        var k = clamp(effect.elapsed / effect.duration, 0, 1);
        effect.update(k);
        if (k >= 1) {
          effect.group.parent && effect.group.parent.remove(effect.group);
          effects.splice(i, 1);
        }
      }
    }

    /* ---------- tata letak bidak ---------- */
    function relayout() {
      var groups = {};
      state.players.forEach(function (player) {
        (groups[player.pos] = groups[player.pos] || []).push(player.index);
      });
      Object.keys(groups).forEach(function (tile) {
        var list = groups[tile];
        var ordered = list
          .filter(function (index) { return state.slots[index] && state.slots[index].tile === Number(tile); })
          .sort(function (a, b) { return state.slots[a].order - state.slots[b].order; })
          .concat(list.filter(function (index) {
            return !state.slots[index] || state.slots[index].tile !== Number(tile);
          }));
        ordered.forEach(function (index, order) {
          state.slots[index] = { tile: Number(tile), order: order };
        });
      });
    }

    function pawnWorld(player) {
      var world = tileToWorld(player.pos);
      var slot = state.slots[player.index];
      var offset = QUADRANTS[(slot ? slot.order : 0) % QUADRANTS.length];
      return { x: world.x + offset[0], z: world.z + offset[1] };
    }

    function snapPawns() {
      relayout();
      state.players.forEach(function (player) {
        var pawn = pawnObjects[player.index].group;
        var world = pawnWorld(player);
        pawn.position.set(world.x, PAWN_BASE_Y, world.z);
        pawn.visible = true;
        pawn.scale.setScalar(0.01);
      });
      state.players.forEach(function (player, index) {
        var pawn = pawnObjects[player.index].group;
        tween(420 + index * 90, function (k) {
          pawn.scale.setScalar(Math.max(0.01, easeOutCubic(k)));
        });
      });
    }

    function hopPawn(player, duration) {
      relayout();
      var pawn = pawnObjects[player.index].group;
      var to = pawnWorld(player);
      var fromX = pawn.position.x;
      var fromZ = pawn.position.z;
      return tween(duration, function (k) {
        var eased = easeInOutQuad(k);
        pawn.position.x = lerp(fromX, to.x, eased);
        pawn.position.z = lerp(fromZ, to.z, eased);
        pawn.position.y = PAWN_BASE_Y + Math.sin(k * Math.PI) * 1.05;
      }).then(function () {
        pawn.position.set(to.x, PAWN_BASE_Y, to.z);
      });
    }

    function slidePawn(player, duration, viaLadder) {
      relayout();
      var pawn = pawnObjects[player.index].group;
      var to = pawnWorld(player);
      var fromX = pawn.position.x;
      var fromZ = pawn.position.z;
      return tween(duration, function (k) {
        var eased = easeInOutQuad(k);
        pawn.position.x = lerp(fromX, to.x, eased) + (viaLadder ? 0 : Math.sin(k * Math.PI * 3) * 0.32);
        pawn.position.z = lerp(fromZ, to.z, eased);
        pawn.position.y = PAWN_BASE_Y + (viaLadder ? Math.sin(k * Math.PI) * 1.3 + k * 0.5 : Math.sin(k * Math.PI) * 0.4);
      }).then(function () {
        pawn.position.set(to.x, PAWN_BASE_Y, to.z);
      });
    }

    /* ---------- dadu ---------- */
    function quaternionForValue(value) {
      var euler;
      if (value === 1) euler = new THREE.Euler(0, 0, Math.PI / 2);
      else if (value === 6) euler = new THREE.Euler(0, 0, -Math.PI / 2);
      else if (value === 2) euler = new THREE.Euler(0, 0, 0);
      else if (value === 5) euler = new THREE.Euler(Math.PI, 0, 0);
      else if (value === 3) euler = new THREE.Euler(-Math.PI / 2, 0, 0);
      else euler = new THREE.Euler(Math.PI / 2, 0, 0);
      return new THREE.Quaternion().setFromEuler(euler);
    }

    function animateDice(value) {
      var startQuaternion = new THREE.Quaternion().setFromEuler(
        new THREE.Euler(Math.random() * 6.28, Math.random() * 6.28, Math.random() * 6.28)
      );
      var endQuaternion = quaternionForValue(value);
      if (Math.random() < 0.5) {
        endQuaternion.set(-endQuaternion.x, -endQuaternion.y, -endQuaternion.z, -endQuaternion.w);
      }
      var startX = dice.position.x;
      var startZ = dice.position.z;
      var targetX = -2.4 + Math.random() * 4.8;
      var targetZ = 12.8 + Math.random() * 1.8;
      return tween(1150, function (k) {
        var eased = easeOutCubic(k);
        dice.quaternion.slerpQuaternions(startQuaternion, endQuaternion, eased);
        dice.position.x = lerp(startX, targetX, eased);
        dice.position.z = lerp(startZ, targetZ, eased);
        dice.position.y = DICE_Y + Math.abs(Math.sin(k * Math.PI * 2.6)) * (1 - k) * 3.4 + (1 - k) * 1.2;
      }).then(function () {
        dice.position.set(targetX, DICE_Y, targetZ);
        dice.quaternion.copy(endQuaternion);
      });
    }

    /* ---------- efek serangan ---------- */
    function burstEffect(position) {
      var group = new THREE.Group();
      group.position.copy(position);
      group.position.y = PAWN_BASE_Y + 0.9;
      var ringMat = new THREE.MeshBasicMaterial({ color: 0xa855f7, transparent: true, opacity: 0.9 });
      var ring = new THREE.Mesh(new THREE.TorusGeometry(0.6, 0.09, 8, 32), ringMat);
      ring.rotation.x = -Math.PI / 2;
      group.add(ring);
      var sparks = [];
      for (var i = 0; i < 10; i += 1) {
        var spark = new THREE.Mesh(
          new THREE.SphereGeometry(0.12, 8, 8),
          new THREE.MeshBasicMaterial({ color: i % 2 ? 0xfbbf24 : 0xa855f7, transparent: true, opacity: 1 })
        );
        var angle = (i / 10) * Math.PI * 2;
        spark.userData.angle = angle;
        sparks.push(spark);
        group.add(spark);
      }
      var light = new THREE.PointLight(0xa855f7, 12, 12);
      group.add(light);
      scene.add(group);
      effects.push({
        group: group,
        elapsed: 0,
        duration: 0.85,
        update: function (k) {
          ring.scale.setScalar(1 + k * 3.4);
          ringMat.opacity = 0.9 * (1 - k);
          light.intensity = 12 * (1 - k);
          sparks.forEach(function (spark) {
            var distance = k * 2.6;
            spark.position.set(Math.cos(spark.userData.angle) * distance, Math.sin(k * Math.PI) * 1.1, Math.sin(spark.userData.angle) * distance);
            spark.material.opacity = 1 - k;
          });
        }
      });
    }

    /* ---------- suara ---------- */
    var audioContext = null;

    function ensureAudio() {
      if (audioContext) return audioContext;
      var Ctor = global.AudioContext || global.webkitAudioContext;
      if (!Ctor) return null;
      try {
        audioContext = new Ctor();
      } catch (error) {
        audioContext = null;
      }
      return audioContext;
    }

    function beep(ctx, frequency, at, duration) {
      var osc = ctx.createOscillator();
      var gain = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(frequency, at);
      gain.gain.setValueAtTime(0.0001, at);
      gain.gain.exponentialRampToValueAtTime(0.16, at + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, at + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(at);
      osc.stop(at + duration + 0.05);
    }

    var SOUNDS = {
      roll: [[300, 0, 0.12], [220, 0.12, 0.12]],
      step: [[540, 0, 0.05]],
      correct: [[660, 0, 0.1], [880, 0.1, 0.16]],
      wrong: [[200, 0, 0.16], [150, 0.16, 0.22]],
      ladder: [[520, 0, 0.08], [660, 0.08, 0.08], [880, 0.16, 0.18]],
      snake: [[320, 0, 0.18], [180, 0.18, 0.26]],
      attack: [[130, 0, 0.2], [90, 0.18, 0.24]],
      win: [[523, 0, 0.12], [659, 0.12, 0.12], [784, 0.24, 0.12], [1047, 0.36, 0.3]]
    };

    function sfx(name) {
      if (!state.soundOn) return;
      var ctx = ensureAudio();
      if (!ctx) return;
      if (ctx.state === "suspended") ctx.resume();
      (SOUNDS[name] || SOUNDS.step).forEach(function (note) {
        beep(ctx, note[0], ctx.currentTime + note[1], note[2]);
      });
    }

    /* ---------- HUD ---------- */
    function statusLabel() {
      if (state.phase === "rolling") return "Dadu berputar ...";
      if (state.phase === "moving") return "Bidak berjalan ...";
      if (state.phase === "quiz") return "Menjawab soal ...";
      if (state.phase === "attack") return "Serangan ...";
      return "&#127922; Lempar Dadu";
    }

    function renderHud() {
      if (state.phase === "setup") return;
      var current = state.players[state.current];
      el.turnText.textContent = state.phase === "over" ? "Permainan selesai" : "Giliran " + current.name;
      el.turnDot.style.background = current.color;
      state.players.forEach(function (player, index) {
        el.cards[index].classList.toggle("is-active", index === state.current && state.phase !== "over");
        el.names[index].textContent = player.name;
        el.positions[index].textContent = "Petak " + player.pos;
        el.scores[index].textContent = player.score + " poin";
      });
      el.diceValue.innerHTML = state.dice ? String(state.dice) : "&#8211;";
      el.diceValue.style.color = current.color;
      var canRoll = state.phase === "idle";
      el.rollBtn.disabled = !canRoll;
      el.rollBtn.innerHTML = canRoll ? "&#127922; Lempar Dadu" : statusLabel();
      el.attackBtn.disabled = !(state.phase === "idle" && current.score >= ATTACK_COST);
      el.attackBtn.innerHTML = "&#9876;&#65039; Serang (" + ATTACK_COST + " poin)";
    }

    function announce(message) {
      el.live.textContent = message;
    }

    function toast(message, kind) {
      var node = document.createElement("div");
      node.className = "ut-toast" + (kind ? " ut-toast-" + kind : "");
      node.setAttribute("data-testid", "toast");
      node.innerHTML = message;
      el.toasts.appendChild(node);
      global.setTimeout(function () {
        node.classList.add("is-out");
        global.setTimeout(function () {
          if (node.parentNode) node.parentNode.removeChild(node);
        }, 320);
      }, 3200);
      while (el.toasts.children.length > 4) {
        el.toasts.removeChild(el.toasts.firstChild);
      }
    }

    /* ---------- modal ---------- */
    function openModal(className, testId, innerHtml) {
      var backdrop = document.createElement("div");
      backdrop.className = "ut-backdrop";
      backdrop.setAttribute("data-testid", testId);
      backdrop.innerHTML = '<div class="ut-modal ' + className + '" role="dialog" aria-modal="true">' + innerHtml + "</div>";
      root.appendChild(backdrop);
      return {
        backdrop: backdrop,
        close: function () {
          if (backdrop.parentNode) backdrop.parentNode.removeChild(backdrop);
        }
      };
    }

    function openQuiz(player, question) {
      var label = CATEGORY_LABELS[question.category] || "Pengetahuan Umum";
      var options = question.options.map(function (option, index) {
        return (
          '<button class="ut-option" type="button" data-option="' + index + '" data-testid="quiz-option-' + index + '">' +
          '<span class="ut-option-key">' + "ABCD".charAt(index) + "</span>" +
          '<span class="ut-option-text">' + escapeHtml(option) + "</span></button>"
        );
      }).join("");
      var modal = openModal(
        "ut-modal-quiz",
        "quiz-modal",
        '<div class="ut-quiz-head">' +
          '<span class="ut-badge ut-badge-' + (question.category || "umum") + '">' + label + "</span>" +
          '<span class="ut-quiz-for">Soal untuk ' + escapeHtml(player.name) + "</span>" +
        "</div>" +
        '<h2 class="ut-quiz-text" data-testid="quiz-question-text">' + escapeHtml(question.text) + "</h2>" +
        '<div class="ut-options">' + options + "</div>" +
        '<div class="ut-feedback" data-testid="quiz-feedback" hidden>' +
          '<p class="ut-feedback-title" data-testid="quiz-result"></p>' +
          '<p class="ut-explanation" data-testid="quiz-explanation"></p>' +
          '<button class="ut-btn ut-btn-primary" type="button" data-testid="quiz-continue-button">Lanjut</button>' +
        "</div>"
      );
      var backdrop = modal.backdrop;
      var buttons = Array.prototype.slice.call(backdrop.querySelectorAll(".ut-option"));
      var feedback = backdrop.querySelector('[data-testid="quiz-feedback"]');
      var result = backdrop.querySelector('[data-testid="quiz-result"]');
      var explanation = backdrop.querySelector('[data-testid="quiz-explanation"]');
      var chosen = -1;

      return new Promise(function (resolve) {
        function answer(index) {
          if (chosen !== -1) return;
          chosen = index;
          var correct = index === question.answer_index;
          buttons.forEach(function (button, i) {
            button.disabled = true;
            if (i === question.answer_index) button.classList.add("is-correct");
            else if (i === index) button.classList.add("is-wrong");
          });
          backdrop.querySelector(".ut-modal").classList.add(correct ? "is-correct" : "is-wrong");
          result.textContent = correct
            ? "\u2705 Jawaban benar! +10 poin"
            : "\u274C Jawaban salah. Jawaban benar: " + question.options[question.answer_index];
          explanation.textContent = question.explanation || "";
          feedback.hidden = false;
          sfx(correct ? "correct" : "wrong");
        }

        function onKey(event) {
          if (chosen !== -1) return;
          if (["1", "2", "3", "4"].indexOf(event.key) !== -1) {
            event.preventDefault();
            answer(Number(event.key) - 1);
          }
        }

        buttons.forEach(function (button, index) {
          button.addEventListener("click", function () { answer(index); });
        });
        backdrop.querySelector('[data-testid="quiz-continue-button"]').addEventListener("click", function () {
          document.removeEventListener("keydown", onKey);
          modal.close();
          resolve(chosen);
        });
        document.addEventListener("keydown", onKey);
        var first = buttons[0];
        if (first) first.focus();
      });
    }

    function openAttackModal() {
      var attacker = state.players[state.current];
      var targets = state.players.filter(function (player) { return player.index !== state.current; });
      var cards = targets.map(function (player) {
        return (
          '<button class="ut-target" type="button" data-target="' + player.index + '" data-testid="attack-target-' + player.index + '">' +
          '<span class="ut-dot" style="background:' + player.color + '"></span>' +
          '<span class="ut-target-meta"><strong>' + escapeHtml(player.name) + "</strong>" +
          '<span>Petak ' + player.pos + " &#183; " + player.score + " poin</span></span>" +
          '<span class="ut-target-cost">Mundur ' + ATTACK_BACK + "</span></button>"
        );
      }).join("");
      var modal = openModal(
        "ut-modal-attack",
        "attack-modal",
        '<h2 class="ut-modal-title">Pilih lawan untuk diserang</h2>' +
        '<p class="ut-modal-sub">' + escapeHtml(attacker.name) + " memakai " + ATTACK_COST + " poin. Lawan yang dipilih mundur " + ATTACK_BACK + " petak.</p>" +
        '<div class="ut-targets">' + cards + "</div>" +
        '<button class="ut-btn ut-btn-secondary" type="button" data-testid="attack-cancel-button">Batal</button>'
      );
      return new Promise(function (resolve) {
        modal.backdrop.querySelectorAll(".ut-target").forEach(function (button) {
          button.addEventListener("click", function () {
            modal.close();
            document.removeEventListener("keydown", onEsc);
            resolve(Number(button.getAttribute("data-target")));
          });
        });
        modal.backdrop.querySelector('[data-testid="attack-cancel-button"]').addEventListener("click", function () {
          modal.close();
          document.removeEventListener("keydown", onEsc);
          resolve(-1);
        });
        function onEsc(event) {
          if (event.key === "Escape") {
            modal.close();
            document.removeEventListener("keydown", onEsc);
            resolve(-1);
          }
        }
        document.addEventListener("keydown", onEsc);
      });
    }

    function openHelpModal() {
      var ladders = Object.keys(LADDERS).map(function (from) { return from + " \u2192 " + LADDERS[from]; }).join(", ");
      var snakes = Object.keys(SNAKES).map(function (from) { return from + " \u2192 " + SNAKES[from]; }).join(", ");
      var modal = openModal(
        "ut-modal-help",
        "help-modal",
        '<h2 class="ut-modal-title">Aturan Permainan</h2>' +
        '<ul class="ut-list">' +
        "<li>Empat pemain bergiliran melempar dadu. Bidak berjalan satu petak demi satu petak.</li>" +
        "<li>Setelah bidak berhenti, muncul satu soal pilihan ganda. Jawaban benar <strong>+10 poin</strong>.</li>" +
        "<li>Jawaban salah membuat pemain <strong>mundur 2 atau 5 petak</strong> secara acak.</li>" +
        "<li>Kumpulkan <strong>" + ATTACK_COST + " poin</strong> untuk menyerang satu lawan: lawan mundur " + ATTACK_BACK + " petak.</li>" +
        "<li>Berhenti di pangkal tangga &#8594; naik. Berhenti di kepala ular &#8594; turun.</li>" +
        "<li>Pemain pertama yang mencapai petak <strong>100</strong> menjadi juara.</li>" +
        "</ul>" +
        '<p class="ut-modal-sub"><strong>Tangga:</strong> ' + ladders + "</p>" +
        '<p class="ut-modal-sub"><strong>Ular:</strong> ' + snakes + "</p>" +
        '<p class="ut-modal-sub">Papan bisa diputar dengan menggeser (drag), dan di-zoom dengan cubit atau roda tetikus.</p>' +
        '<button class="ut-btn ut-btn-primary" type="button" data-testid="help-close-button">Mengerti</button>'
      );
      modal.backdrop.querySelector('[data-testid="help-close-button"]').addEventListener("click", function () {
        modal.close();
      });
    }

    function openVictoryModal(winner) {
      var ranked = state.players.slice().sort(function (a, b) {
        if (b.pos !== a.pos) return b.pos - a.pos;
        return b.score - a.score;
      });
      var medals = ["\uD83E\uDD47", "\uD83E\uDD48", "\uD83E\uDD49", "4"];
      var podium = ranked.map(function (player, index) {
        return (
          '<div class="ut-podium-row' + (player.index === winner.index ? " is-winner" : "") + '" data-testid="podium-rank-' + (index + 1) + '">' +
          '<span class="ut-podium-medal">' + medals[index] + "</span>" +
          '<span class="ut-dot" style="background:' + player.color + '"></span>' +
          '<strong>' + escapeHtml(player.name) + "</strong>" +
          '<span class="ut-podium-meta">Petak ' + player.pos + " &#183; " + player.score + " poin</span>" +
          "</div>"
        );
      }).join("");
      var modal = openModal(
        "ut-modal-victory",
        "victory-modal",
        '<p class="ut-overline">Pemenang</p>' +
        '<h2 class="ut-winner" data-testid="winner-name">' + escapeHtml(winner.name) + "</h2>" +
        '<p class="ut-modal-sub">Mencapai petak 100 dengan ' + winner.score + " poin. Hebat!</p>" +
        '<div class="ut-podium">' + podium + "</div>" +
        '<div class="ut-modal-actions">' +
        '<button class="ut-btn ut-btn-primary" type="button" data-testid="play-again-button">Main Lagi</button>' +
        '<button class="ut-btn ut-btn-secondary" type="button" data-testid="back-to-menu-button">Menu Utama</button>' +
        "</div>"
      );
      confetti();
      return new Promise(function (resolve) {
        modal.backdrop.querySelector('[data-testid="play-again-button"]').addEventListener("click", function () {
          modal.close();
          resolve("again");
        });
        modal.backdrop.querySelector('[data-testid="back-to-menu-button"]').addEventListener("click", function () {
          modal.close();
          resolve("menu");
        });
      });
    }

    function confetti() {
      var colors = ["#EF4444", "#0EA5E9", "#F59E0B", "#10B981", "#A855F7", "#FBBF24"];
      var layer = document.createElement("div");
      layer.className = "ut-confetti";
      for (var i = 0; i < 60; i += 1) {
        var piece = document.createElement("span");
        piece.style.left = Math.random() * 100 + "%";
        piece.style.background = colors[i % colors.length];
        piece.style.animationDelay = (Math.random() * 0.9).toFixed(2) + "s";
        piece.style.animationDuration = (2.4 + Math.random() * 1.8).toFixed(2) + "s";
        piece.style.transform = "rotate(" + Math.floor(Math.random() * 360) + "deg)";
        layer.appendChild(piece);
      }
      root.appendChild(layer);
      global.setTimeout(function () {
        if (layer.parentNode) layer.parentNode.removeChild(layer);
      }, 4600);
    }

    /* ---------- alur permainan ---------- */
    function currentPlayer() {
      return state.players[state.current];
    }

    function pickQuestion() {
      var pool = state.questions;
      if (!pool.length) {
        state.questions = DEFAULT_QUESTIONS.slice();
        pool = state.questions;
      }
      for (var attempt = 0; attempt < 12; attempt += 1) {
        var candidate = pool[Math.floor(Math.random() * pool.length)];
        var key = candidate.id || candidate.text;
        if (state.recentQuestions.indexOf(key) === -1) {
          state.recentQuestions.push(key);
          if (state.recentQuestions.length > Math.min(10, pool.length - 1)) state.recentQuestions.shift();
          return candidate;
        }
      }
      return pool[Math.floor(Math.random() * pool.length)];
    }

    function resolveSnakesAndLadders(player) {
      var from = player.pos;
      var target = null;
      var kind = null;
      if (LADDERS[from]) {
        target = LADDERS[from];
        kind = "ladder";
      } else if (SNAKES[from]) {
        target = SNAKES[from];
        kind = "snake";
      }
      if (!kind) return Promise.resolve();

      player.pos = target;
      renderHud();
      if (kind === "ladder") {
        sfx("ladder");
        toast("\uD83E\uDE9C " + escapeHtml(player.name) + " naik tangga dari petak " + from + " ke petak " + target + "!");
        announce(player.name + " naik tangga ke petak " + target);
      } else {
        sfx("snake");
        toast("\uD83D\uDC0D " + escapeHtml(player.name) + " dimakan ular! Turun dari petak " + from + " ke petak " + target + ".");
        announce(player.name + " turun karena ular ke petak " + target);
      }
      return slidePawn(player, kind === "ladder" ? 900 : 1100, kind === "ladder").then(function () {
        renderHud();
      });
    }

    function movePlayerBack(player, steps) {
      var remaining = steps;
      function step() {
        if (remaining <= 0 || player.pos <= 1) return Promise.resolve();
        remaining -= 1;
        player.pos = Math.max(1, player.pos - 1);
        return hopPawn(player, 260).then(function () {
          sfx("step");
          renderHud();
          return step();
        });
      }
      return step().then(function () {
        return resolveSnakesAndLadders(player);
      });
    }

    function nextTurn() {
      state.current = (state.current + 1) % state.players.length;
      state.phase = "idle";
      state.dice = 0;
      renderHud();
      announce("Giliran " + currentPlayer().name);
    }

    function askQuestion() {
      var player = currentPlayer();
      state.phase = "quiz";
      renderHud();
      var question = pickQuestion();
      return openQuiz(player, question).then(function (chosen) {
        if (chosen === question.answer_index) {
          player.score += 10;
          toast("\u2705 " + escapeHtml(player.name) + " menjawab benar! +10 poin");
          announce(player.name + " menjawab benar dan mendapat 10 poin");
          renderHud();
          return null;
        }
        var back = Math.random() < 0.5 ? 2 : 5;
        toast("\u274C Jawaban salah. " + escapeHtml(player.name) + " mundur " + back + " petak.");
        announce(player.name + " menjawab salah dan mundur " + back + " petak");
        renderHud();
        return movePlayerBack(player, back);
      });
    }

    function winGame(winner) {
      state.phase = "over";
      renderHud();
      sfx("win");
      announce(winner.name + " mencapai petak 100 dan menjadi juara!");
      return openVictoryModal(winner).then(function (choice) {
        if (choice === "again") {
          restart();
        } else {
          backToMenu();
        }
        return "handled";
      });
    }

    function rollDice() {
      if (state.phase !== "idle") return;
      var player = currentPlayer();
      state.phase = "rolling";
      renderHud();
      sfx("roll");
      var value = 1 + Math.floor(Math.random() * 6);
      return animateDice(value)
        .then(function () {
          state.dice = value;
          announce("Dadu " + player.name + " menunjukkan angka " + value + ". Bidak siap berjalan.");
          toast("\uD83C\uDFB2 " + escapeHtml(player.name) + " mendapat angka <strong>" + value + "</strong>");
          state.phase = "moving";
          renderHud();
          var steps = Math.min(value, WIN_TILE - player.pos);
          var chain = Promise.resolve();
          for (var i = 0; i < steps; i += 1) {
            chain = chain.then(function () {
              player.pos += 1;
              return hopPawn(player, STEP_MS).then(function () {
                sfx("step");
                renderHud();
              });
            });
          }
          return chain.then(function () {
            if (steps < value) {
              toast("\uD83C\uDFAF Angka berlebih, bidak berhenti tepat di petak 100!");
              announce(player.name + " berhenti tepat di petak 100");
            }
            return wait(140);
          });
        })
        .then(function () {
          if (player.pos >= WIN_TILE) {
            player.pos = WIN_TILE;
            relayout();
            renderHud();
            return winGame(player);
          }
          return resolveSnakesAndLadders(player).then(function () {
            return askQuestion();
          });
        })
        .then(function (outcome) {
          if (outcome === "handled") return;
          if (state.phase !== "over") nextTurn();
        });
    }

    function attack(targetIndex) {
      var attacker = currentPlayer();
      if (state.phase !== "idle" || attacker.score < ATTACK_COST) return;
      var target = state.players[targetIndex];
      if (!target || target.index === attacker.index) return;
      attacker.score -= ATTACK_COST;
      state.phase = "attack";
      renderHud();
      sfx("attack");
      burstEffect(pawnObjects[target.index].group.position);
      toast("\u2694\uFE0F " + escapeHtml(attacker.name) + " menyerang " + escapeHtml(target.name) + "! " + escapeHtml(target.name) + " mundur " + ATTACK_BACK + " petak.");
      announce(attacker.name + " menyerang " + target.name + ", mundur " + ATTACK_BACK + " petak");
      return movePlayerBack(target, ATTACK_BACK).then(function () {
        state.phase = "idle";
        renderHud();
      });
    }

    function startGame() {
      var names = el.inputs.map(function (input, index) {
        var value = (input.value || "").trim();
        return value || PLAYER_PRESETS[index].name;
      });
      state.players = names.map(function (name, index) {
        return {
          index: index,
          name: name.slice(0, 14),
          color: PLAYER_PRESETS[index].color,
          soft: PLAYER_PRESETS[index].soft,
          pos: 1,
          score: 0
        };
      });
      state.current = 0;
      state.dice = 0;
      state.phase = "idle";
      state.slots = {};
      state.recentQuestions = [];
      el.setup.classList.add("is-hidden");
      root.classList.add("ut-playing");
      snapPawns();
      cam.targetTheta = 0;
      cam.targetPhi = 0.86;
      cam.targetRadius = cam.fit;
      cam.theta = 0;
      renderHud();
      toast("Selamat bermain! " + escapeHtml(state.players[0].name) + " mulai duluan.");
      announce("Permainan dimulai. Giliran " + state.players[0].name);
    }

    function restart() {
      state.players.forEach(function (player) {
        player.pos = 1;
        player.score = 0;
      });
      state.current = 0;
      state.dice = 0;
      state.phase = "idle";
      state.slots = {};
      var pawns = pawnObjects;
      state.players.forEach(function (player) {
        pawns[player.index].group.visible = true;
      });
      snapPawns();
      renderHud();
      toast("\uD83C\uDFAE Permainan baru dimulai!");
      announce("Permainan baru dimulai. Giliran " + currentPlayer().name);
    }

    function backToMenu() {
      state.phase = "setup";
      state.current = 0;
      state.dice = 0;
      state.players.forEach(function (player) {
        player.pos = 1;
        player.score = 0;
      });
      state.slots = {};
      pawnObjects.forEach(function (pawn) { pawn.group.visible = false; });
      root.classList.remove("ut-playing");
      el.setup.classList.remove("is-hidden");
      renderHud();
      spin = 0;
    }

    /* ---------- interaksi ---------- */
    function onKeyDown(event) {
      if (state.phase === "setup" || state.phase === "over") return;
      if (event.key === " " || event.key === "Enter") {
        if (document.activeElement && document.activeElement.classList.contains("ut-input")) return;
        event.preventDefault();
        rollDice();
      }
    }

    function bindPointer() {
      var pointers = {};
      var lastPinch = 0;

      el.canvas.addEventListener("pointerdown", function (event) {
        pointers[event.pointerId] = { x: event.clientX, y: event.clientY };
        el.canvas.setPointerCapture(event.pointerId);
      });

      el.canvas.addEventListener("pointermove", function (event) {
        var previous = pointers[event.pointerId];
        if (!previous) return;
        var deltaX = event.clientX - previous.x;
        var deltaY = event.clientY - previous.y;
        previous.x = event.clientX;
        previous.y = event.clientY;
        var ids = Object.keys(pointers);
        if (ids.length === 1) {
          cam.targetTheta = state.phase === "setup" ? cam.targetTheta : cam.targetTheta + deltaX * 0.006;
          cam.theta = state.phase === "setup" ? cam.theta : cam.theta + deltaX * 0.006;
          cam.targetPhi = clamp(cam.targetPhi - deltaY * 0.004, 0.12, 1.32);
        } else if (ids.length === 2) {
          var a = pointers[ids[0]];
          var b = pointers[ids[1]];
          var distance = Math.hypot(a.x - b.x, a.y - b.y);
          if (lastPinch) {
            cam.targetRadius = clamp(cam.targetRadius * (lastPinch / distance), cam.fit * 0.55, cam.fit * 1.5);
          }
          lastPinch = distance;
        }
      });

      function release(event) {
        delete pointers[event.pointerId];
        lastPinch = 0;
      }
      el.canvas.addEventListener("pointerup", release);
      el.canvas.addEventListener("pointercancel", release);

      el.canvas.addEventListener(
        "wheel",
        function (event) {
          event.preventDefault();
          cam.targetRadius = clamp(cam.targetRadius * (1 + event.deltaY * 0.0009), cam.fit * 0.55, cam.fit * 1.5);
        },
        { passive: false }
      );
    }

    function bindUi() {
      root.querySelector('[data-testid="start-game-button"]').addEventListener("click", startGame);
      el.rollBtn.addEventListener("click", function () { rollDice(); });
      el.attackBtn.addEventListener("click", function () {
        if (state.phase !== "idle" || currentPlayer().score < ATTACK_COST) return;
        openAttackModal().then(function (target) {
          if (target >= 0) attack(target);
        });
      });
      el.cameraBtn.addEventListener("click", function () {
        if (state.cameraMode === "iso") {
          state.cameraMode = "top";
          cam.targetPhi = 0.1;
          cam.targetTheta = 0;
        } else {
          state.cameraMode = "iso";
          cam.targetPhi = 0.86;
        }
        toast(state.cameraMode === "top" ? "Kamera tampak atas" : "Kamera 3D");
      });
      el.soundBtn.addEventListener("click", function () {
        state.soundOn = !state.soundOn;
        el.soundBtn.innerHTML = state.soundOn ? "&#128266;" : "&#128263;";
        el.soundBtn.classList.toggle("is-off", !state.soundOn);
        if (state.soundOn) sfx("step");
      });
      el.helpBtn.addEventListener("click", openHelpModal);
      document.addEventListener("keydown", onKeyDown);
      bindPointer();
    }

    /* ---------- data soal ---------- */
    function loadQuestions() {
      var url = apiBase + "/questions";
      return global
        .fetch(url, { headers: { Accept: "application/json" } })
        .then(function (response) {
          if (!response.ok) throw new Error("HTTP " + response.status);
          return response.json();
        })
        .then(function (list) {
          var clean = sanitizeQuestions(list);
          if (!clean.length) throw new Error("bank soal kosong");
          state.questions = clean;
          state.questionSource = "server";
        })
        .catch(function () {
          state.questions = DEFAULT_QUESTIONS.slice();
          state.questionSource = "bawaan";
        })
        .then(function () {
          el.note.innerHTML =
            state.questionSource === "server"
              ? "\u2705 Bank soal aktif: <strong>" + state.questions.length + " soal</strong> dari server (kelola di halaman Bank Soal)."
              : "\uD83D\uDCD8 Memakai <strong>" + state.questions.length + " soal bawaan</strong> (offline). Server bank soal tidak terjangkau.";
        });
    }

    /* ---------- siapkan ---------- */
    bindUi();
    fitCamera();
    loadQuestions();
    renderHud();

    var resizeObserver = null;
    if (global.ResizeObserver) {
      resizeObserver = new ResizeObserver(function () {
        fitCamera();
      });
      resizeObserver.observe(root);
    }
    global.addEventListener("resize", fitCamera);
    if (global.document.fonts && global.document.fonts.ready) {
      global.document.fonts.ready.then(function () {
        var canvas = drawBoardCanvas();
        boardTexture.image = canvas;
        boardTexture.needsUpdate = true;
      });
    }

    /* ---------- bersihkan ---------- */
    var destroyed = false;
    function destroy() {
      if (destroyed) return;
      destroyed = true;
      renderer.setAnimationLoop(null);
      document.removeEventListener("keydown", onKeyDown);
      global.removeEventListener("resize", fitCamera);
      if (resizeObserver) resizeObserver.disconnect();
      tweens.length = 0;
      effects.length = 0;
      scene.traverse(function (object) {
        if (object.geometry && object.geometry.dispose) object.geometry.dispose();
        var material = object.material;
        if (Array.isArray(material)) material.forEach(disposeMaterial);
        else if (material) disposeMaterial(material);
      });
      boardTexture.dispose();
      renderer.dispose();
      root.classList.remove("ut-playing", "ut-root");
      root.innerHTML = "";
    }

    function disposeMaterial(material) {
      if (material.map) material.map.dispose();
      material.dispose();
    }

    return { destroy: destroy, state: state };
  }

  /* ------------------------- pembuat geometri ---------------------------- */

  function buildLadder(from, to, railMaterial) {
    var startWorld = tileToWorld(from);
    var endWorld = tileToWorld(to);
    var start = new THREE.Vector3(startWorld.x, BOARD_TOP + 0.12, startWorld.z);
    var end = new THREE.Vector3(endWorld.x, BOARD_TOP + 0.12, endWorld.z);
    var direction = new THREE.Vector3().subVectors(end, start);
    var length = direction.length();
    var group = new THREE.Group();
    var side = new THREE.Vector3(-direction.z, 0, direction.x).normalize().multiplyScalar(0.52);

    [1, -1].forEach(function (sign) {
      var rail = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, length, 8), railMaterial);
      rail.position.copy(start).add(end).multiplyScalar(0.5).addScaledVector(side, sign);
      rail.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.clone().normalize());
      rail.castShadow = true;
      group.add(rail);
    });

    var rungs = Math.max(3, Math.round(length / 1.05));
    var rungGeometry = new THREE.CylinderGeometry(0.07, 0.07, 1.15, 8);
    for (var i = 1; i <= rungs; i += 1) {
      var rung = new THREE.Mesh(rungGeometry, railMaterial);
      rung.position.copy(start).lerp(end, i / (rungs + 1));
      rung.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), side.clone().normalize());
      rung.castShadow = true;
      group.add(rung);
    }
    return group;
  }

  function buildSnake(from, to, color, phase) {
    var headWorld = tileToWorld(from);
    var tailWorld = tileToWorld(to);
    var start = new THREE.Vector3(headWorld.x, BOARD_TOP + 0.42, headWorld.z);
    var end = new THREE.Vector3(tailWorld.x, BOARD_TOP + 0.28, tailWorld.z);
    var group = new THREE.Group();
    var material = new THREE.MeshStandardMaterial({ color: color, roughness: 0.45, metalness: 0.05 });
    var perpendicular = new THREE.Vector3(-(end.z - start.z), 0, end.x - start.x).normalize().multiplyScalar(0.95);

    var points = [];
    var segments = 7;
    for (var i = 0; i <= segments; i += 1) {
      var t = i / segments;
      var point = new THREE.Vector3().lerpVectors(start, end, t);
      var wobble = Math.sin(t * Math.PI * 3 + phase) * (0.9 * Math.sin(t * Math.PI) + 0.2);
      point.addScaledVector(perpendicular, wobble);
      point.y = BOARD_TOP + 0.34 + Math.sin(t * Math.PI * 2 + phase) * 0.1;
      points.push(point);
    }
    var curve = new THREE.CatmullRomCurve3(points);
    var body = new THREE.Mesh(new THREE.TubeGeometry(curve, 72, 0.21, 8, false), material);
    body.castShadow = true;
    group.add(body);

    var headDirection = new THREE.Vector3(end.x - start.x, 0, end.z - start.z).normalize();
    var head = new THREE.Mesh(new THREE.SphereGeometry(0.44, 20, 16), material);
    head.position.copy(start);
    head.position.y = BOARD_TOP + 0.42;
    head.castShadow = true;
    group.add(head);

    var eyeWhite = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3 });
    var eyeBlack = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.3 });
    [-1, 1].forEach(function (sign) {
      var eye = new THREE.Mesh(new THREE.SphereGeometry(0.14, 12, 10), eyeWhite);
      eye.position
        .copy(start)
        .addScaledVector(perpendicular.clone().normalize(), 0.17 * sign)
        .addScaledVector(headDirection, 0.2);
      eye.position.y = BOARD_TOP + 0.62;
      var pupil = new THREE.Mesh(new THREE.SphereGeometry(0.07, 10, 8), eyeBlack);
      pupil.position.copy(eye.position).addScaledVector(headDirection, 0.09);
      pupil.position.y = BOARD_TOP + 0.64;
      group.add(eye);
      group.add(pupil);
    });

    var tongue = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.06, 0.5), new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.5 }));
    tongue.position.copy(start).addScaledVector(headDirection, 0.42);
    tongue.position.y = BOARD_TOP + 0.32;
    tongue.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), headDirection);
    group.add(tongue);
    return group;
  }

  function buildPawn(color) {
    var material = new THREE.MeshPhysicalMaterial({
      color: color,
      roughness: 0.25,
      metalness: 0.05,
      clearcoat: 0.6,
      clearcoatRoughness: 0.25
    });
    var group = new THREE.Group();
    var parts = [
      new THREE.Mesh(new THREE.CylinderGeometry(0.44, 0.5, 0.18, 24), material),
      new THREE.Mesh(new THREE.ConeGeometry(0.36, 0.9, 24), material),
      new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.07, 10, 24), material),
      new THREE.Mesh(new THREE.SphereGeometry(0.27, 20, 16), material)
    ];
    parts[0].position.y = 0.09;
    parts[1].position.y = 0.63;
    parts[2].rotation.x = Math.PI / 2;
    parts[2].position.y = 1.06;
    parts[3].position.y = 1.3;
    parts.forEach(function (part) {
      part.castShadow = true;
      group.add(part);
    });

    var marker = new THREE.Mesh(
      new THREE.TorusGeometry(0.66, 0.07, 8, 32),
      new THREE.MeshBasicMaterial({ color: 0xf59e0b, transparent: true, opacity: 0.8 })
    );
    marker.rotation.x = -Math.PI / 2;
    marker.position.y = 0.03;
    marker.visible = false;
    group.add(marker);
    group.userData.bodyMeshes = parts;
    return { group: group, marker: marker };
  }

  function drawPipCanvas(value) {
    var size = 256;
    var canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size;
    var ctx = canvas.getContext("2d");
    var gradient = ctx.createLinearGradient(0, 0, size, size);
    gradient.addColorStop(0, "#FFFDF5");
    gradient.addColorStop(1, "#F6E3C5");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, size, size);
    ctx.strokeStyle = "rgba(120, 53, 15, 0.35)";
    ctx.lineWidth = 14;
    ctx.strokeRect(7, 7, size - 14, size - 14);
    var gap = 62;
    (PIPS[value] || []).forEach(function (spot) {
      var x = size / 2 + (spot[0] - 1) * gap;
      var y = size / 2 + (spot[1] - 1) * gap;
      ctx.beginPath();
      ctx.fillStyle = value === 1 ? "#DC2626" : "#1E293B";
      ctx.arc(x, y, 24, 0, Math.PI * 2);
      ctx.fill();
    });
    return canvas;
  }

  function drawBoardCanvas() {
    var size = 2048;
    var cell = size / 10;
    var canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size;
    var ctx = canvas.getContext("2d");

    ctx.fillStyle = "#FFF8E5";
    ctx.fillRect(0, 0, size, size);

    for (var tile = 1; tile <= WIN_TILE; tile += 1) {
      var grid = gridOf(tile);
      var x = grid.col * cell;
      var y = (9 - grid.row) * cell;
      var isLadder = Boolean(LADDERS[tile]);
      var isSnake = Boolean(SNAKES[tile]);
      var fill = tile % 2 === 0 ? "#FEF08A" : "#FED7AA";
      if (isLadder) fill = "#BBF7D0";
      else if (isSnake) fill = "#FECDD3";
      if (tile === 1) fill = "#E0F2FE";
      if (tile === WIN_TILE) fill = "#FDE047";

      roundRect(ctx, x + 5, y + 5, cell - 10, cell - 10, cell * 0.16);
      ctx.fillStyle = fill;
      ctx.fill();
      ctx.lineWidth = 4;
      ctx.strokeStyle = "rgba(120, 53, 15, 0.22)";
      ctx.stroke();

      ctx.fillStyle = tile === WIN_TILE ? "#7C2D12" : "#78350F";
      ctx.font = "800 " + Math.round(cell * 0.44) + 'px Poppins, "Plus Jakarta Sans", "Trebuchet MS", sans-serif';
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(String(tile), x + cell / 2, y + cell / 2 + cell * 0.02);

      ctx.font = Math.round(cell * 0.26) + 'px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif';
      ctx.globalAlpha = 0.95;
      if (isLadder) ctx.fillText("\uD83E\uDE9C", x + cell * 0.76, y + cell * 0.78);
      else if (isSnake) ctx.fillText("\uD83D\uDC0D", x + cell * 0.76, y + cell * 0.78);
      ctx.globalAlpha = 1;

      if (tile === 1) {
        ctx.fillStyle = "#0369A1";
        ctx.font = "700 " + Math.round(cell * 0.17) + "px Poppins, sans-serif";
        ctx.fillText("START", x + cell / 2, y + cell * 0.82);
      }
      if (tile === WIN_TILE) {
        ctx.fillStyle = "#B45309";
        ctx.font = "700 " + Math.round(cell * 0.17) + "px Poppins, sans-serif";
        ctx.fillText("FINISH", x + cell * 0.5, y + cell * 0.82);
      }
    }
    return canvas;
  }

  function roundRect(ctx, x, y, width, height, radius) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.arcTo(x + width, y, x + width, y + height, radius);
    ctx.arcTo(x + width, y + height, x, y + height, radius);
    ctx.arcTo(x, y + height, x, y, radius);
    ctx.arcTo(x, y, x + width, y, radius);
    ctx.closePath();
  }

  global.UlarTanggaEngine = {
    createGame: createGame,
    DEFAULT_QUESTIONS: DEFAULT_QUESTIONS,
    CATEGORY_LABELS: CATEGORY_LABELS,
    LADDERS: LADDERS,
    SNAKES: SNAKES
  };
})(window);
