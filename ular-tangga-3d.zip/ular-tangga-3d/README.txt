ULAR TANGGA 3D — 4 PEMAIN
=========================
Game papan ular tangga 3D untuk 4 pemain (bergantian di satu perangkat),
dibuat dengan HTML5 + CSS3 + JavaScript murni dan tiga.js (WebGL).
Tidak butuh database, tidak butuh login, tidak butuh server khusus.


CARA MENJALANKAN
----------------
1) Paling cepat: klik dua kali berkas "index.html".
   Game langsung berjalan di browser (semua berkas sudah menyatu, tanpa internet).

2) Kalau browser membatasi sesuatu (misalnya font tidak muncul saat dibuka
   lewat file://), jalankan server lokal sederhana dari folder ini:
      python -m http.server 8080
   lalu buka  http://localhost:8080

3) Hosting gratis (GitHub Pages / Netlify):
   - GitHub Pages: buat repositori, unggah SELURUH isi folder ini ke repositori,
     lalu aktifkan Settings > Pages > Deploy from branch (folder root).
   - Netlify Drop: buka app.netlify.com/drop dan tarik (drag) folder ini ke halaman itu.
   Tidak perlu proses build apa pun.


SUSUNAN BERKAS
--------------
  index.html            Halaman utama game
  style.css             Seluruh tampilan (termasuk font lokal)
  game.js               Mesin permainan: papan, dadu, bidak, soal, serangan, kemenangan
  README.txt            Berkas ini
  lib/three.js          tiga.js versi skrip klasik (WebGL, sudah dibundel)
  fonts/*.woff2         Font Poppins, Plus Jakarta Sans, IBM Plex Mono (lokal)


CARA BERMAIN
------------
- Isi nama 4 pemain, lalu tekan "Mulai Bermain".
- Pemain bergantian melempar dadu. Bidak berjalan satu petak demi satu petak.
- Setelah bidak berhenti, satu soal pilihan ganda muncul:
    jawaban benar  -> +10 poin
    jawaban salah  -> bidak mundur 2 atau 5 petak secara acak
- Poin 20 bisa dipakai untuk menyerang satu lawan (lawan mundur 3 petak).
- Berhenti di pangkal tangga -> naik. Berhenti di kepala ular -> turun.
- Pemain pertama yang mencapai petak 100 menjadi juara (ada podium dan konfeti).

Kontrol:
- Geser (drag) pada papan untuk memutar kamera, cubit/roda tetikus untuk zoom.
- Tombol kamera (kiri atas) untuk berpindah antara tampak 3D dan tampak atas.
- Spasi / Enter untuk melempar dadu, tombol 1-4 untuk memilih jawaban soal.


MENGUBAH / MENAMBAH SOAL
------------------------
Buka game.js dengan editor teks apa pun, cari tulisan:

    var DEFAULT_QUESTIONS = [

Setiap soal ditulis dalam satu blok seperti ini:

    {
      text: "Hasil dari 7 x 8 adalah ...",
      options: ["48", "54", "56", "64"],
      answer_index: 2,                 <-- indeks jawaban benar (0 = pilihan pertama)
      explanation: "7 x 8 = 56.",
      category: "matematika"           <-- matematika | ipa | ips | bahasa | teknologi | umum
    },

Simpan berkas, lalu muat ulang halaman. Jumlah soal bebas (minimal 1).


CATATAN TEKNIS
--------------
- Semua animasi (dadu berputar, bidak melompat, ular/tangga, serangan) dijalankan
  oleh perulangan requestAnimationFrame di game.js.
- Bidak berjalan bertahap: 330 ms per petak, lalu pertanyaan baru muncul.
- Angka dadu yang terlihat di kubus 3D selalu sama dengan angka yang dipakai
  untuk menggerakkan bidak.
- Tersedia juga versi daring yang memakai Bank Soal dari server (bisa menambah,
  mengedit, dan menghapus soal lewat halaman Bank Soal); berkas di folder ini
  otomatis memakai daftar soal bawaan di atas karena tidak ada server.
